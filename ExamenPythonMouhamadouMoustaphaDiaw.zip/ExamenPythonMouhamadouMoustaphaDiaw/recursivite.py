def divinRec(a, b):
    if a < b:
        return 0
    else:
        return 1 + divinRec(a-b, b)


a = 17
b = 3
print(divinRec(a, b))  # Affiche le résultat de la division entière de a par b

def fact(a, b):
    if b == 0:
        return 1
    else:
        return a * fact(a-1, b-1)


a = 5
b = 3
print(fact(a, b))  # Affiche le résultat de a! en utilisant la fonction recursive fact