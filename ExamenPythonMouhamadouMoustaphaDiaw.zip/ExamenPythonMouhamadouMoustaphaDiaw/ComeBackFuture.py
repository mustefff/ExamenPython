import random


PERSONNE_FIELDS = ['nom', 'annee', 'temps']
Personne = dict.fromkeys(PERSONNE_FIELDS)

# saisie des noms des personnes
def Saisie():
    t = []
    while True:
        nom = input("Entrez le nom de la personne (ou 'q' pour quitter) : ")
        if nom.lower() == 'q':
            break
        t.append({ 'nom': nom })
    return t

#  calcul de l'année pour chaque personne
def calculAnnee(t):
    for personne in t:
        annee_min = personne['annee'] - 10000
        annee_max = personne['annee'] + 10000
        periode = input(f"{personne['nom']}, entrez la période souhaitée (entre {annee_min} et {annee_max}) : ")
        annee = random.randint(int(periode), personne['annee'])
        personne['annee'] = annee

#  calcul du temps pour chaque personne
def calculTemps(t):
    for personne in t:
        temps = 0
        annee = personne['annee']
        while annee < 2017:
            temps += 10
            annee += 10
        while annee > 2017:
            temps += 10
            annee -= 10
        personne['temps'] = temps

# Programme principal
t = Saisie()
for personne in t:
    personne['annee'] = int(input(f"{personne['nom']}, entrez l'année actuelle : "))
calculAnnee(t)
calculTemps(t)
for personne in t:
    print(f"{personne['nom']} : temps nécessaire pour revenir en 2017 = {personne['temps']} secondes")