
PERSONNE_CHAMPS = ['nom', 'prenom', 'numero', 'nom_rue', 'telephone', 'code_postal', 'ville']
Personne = dict.fromkeys(PERSONNE_CHAMPS)

#       Bon là c'est la partie définition de l'annuaire comme une liste de personnes
annuaire = []

def saisie_tab():
    """
    Saisie des informations pour chaque personne dans l'annuaire
    """
    while True:
        personne = Personne.copy()
        for champ in PERSONNE_CHAMPS:
            personne[champ] = input(f"Entrez le champ {champ} : ")
        annuaire.append(personne)
        continuer = input("Voulez-vous ajouter une autre personne ? (O/N) ")
        if continuer.lower() == "n":
            break
    return annuaire

def critere_recherche():
    """
    Demande à l'utilisateur de choisir le critère de recherche et retourne ce choix
    """
    choix = input("Choisissez le critère de recherche (nom, prenom, nom_rue, telephone, code_postal, ville) : ")
    return choix

def recherche(annuaire, critere):
    """
    Recherche dans l'annuaire en fonction du critère choisi et retourne un tableau booléen
    """

    
    tableau_bool = []
    for personne in annuaire:
        valeur = personne[critere]
        recherche = input(f"Entrez la valeur de recherche pour le critère {critere} : ")
        tableau_bool.append(recherche == valeur)
    return tableau_bool

def affiche_tab(annuaire, tableau_bool):
    """
    Affiche les informations des personnes correspondant aux critères de recherche
    """
    for i, personne in enumerate(annuaire):
        if tableau_bool[i]:
            print("Nom :", personne['nom'])
            print("Prénom :", personne['prenom'])
            print("Numéro :", personne['numero'])
            print("Nom rue :", personne['nom_rue'])
            print("Téléphone :", personne['telephone'])
            print("Code postal :", personne['code_postal'])
            print("Ville :", personne['ville'])
            print()

# ça c'est le programme principal
annuaire = saisie_tab()
critere = critere_recherche()
tableau_bool = recherche(annuaire, critere)
affiche_tab(annuaire, tableau_bool)