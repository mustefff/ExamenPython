def nbMotsAvecVoyelle(nomf):
    voyelles = ['a', 'e', 'i', 'o', 'u', 'y']
    nb_mots = 0
    with open(nomf, 'r') as f:
        for ligne in f:
            mot = ligne.strip()
            if mot[0] in voyelles:
                nb_mots += 1
    return nb_mots

def compteChaqueMot(nomf1, nomf2):
    with open(nomf1, 'r') as f1, open(nomf2, 'w') as f2:
        mot_prec = ''
        nb_occurences = 0
        for ligne in f1:
            mot = ligne.strip()
            if mot == mot_prec:
                nb_occurences += 1
            else:
                if mot_prec != '':
                    f2.write(f"{mot_prec} {nb_occurences}\n")
                mot_prec = mot
                nb_occurences = 1
        
        if mot_prec != '':
            f2.write(f"{mot_prec} {nb_occurences}\n")
